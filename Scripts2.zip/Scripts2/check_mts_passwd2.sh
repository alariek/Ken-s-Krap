#!/usr/bin/ksh
#set -x

for name in `cat $1`
do
        grep -w $name /home/alariek/nis_cleanup/passwd.oma3nisl1 > /dev/null
        if [ $? -eq 0 ]
  then
	 echo "$name is in  MTS passwd" >> mts_nis_check.out

	else
	echo "" >>mts_nis_check.out

fi
done
