#!/usr/bin/ksh

echo "Remove from $2 list"
echo ""
for name in `cat $1`
do
        grep -w $name ./$2 >> dup_list
done
