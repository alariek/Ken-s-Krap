useradd -u 111477 -g b24dev -d /home/gardnerr -m -c "Richard Gardner <richard.gardner@aciworldwide.com>" gardnerr
echo Welcome2ACI |passwd gardnerr --stdin
useradd -u 3337 -g b24dev -d /home/bowlingc -m -c "Chris Bowling <christopher.bowling@aciworldwide.com>" bowlingc
echo Welcome2ACI |passwd bowlingc --stdin
useradd -u 4404 -g b24dev -d /home/grayp -m -c "Peter Gray <peter.gray@aciworldwide.com>" grayp
echo Welcome2ACI |passwd grayp --stdin

useradd -u 111477 -g sudo_c_dev -d /home/gardnerr -m -c "Richard Gardner <richard.gardner@aciworldwide.com>" gardnerr
echo Welcome2ACI |passwd gardnerr --stdin
useradd -u 3337 -g sudo_c_dev -d /home/bowlingc -m -c "Chris Bowling <christopher.bowling@aciworldwide.com>" bowlingc
echo Welcome2ACI |passwd bowlingc --stdin
useradd -u 4404 -g sudo_c_dev -d /home/grayp -m -c "Peter Gray <peter.gray@aciworldwide.com>" grayp
echo Welcome2ACI |passwd grayp --stdin

## gardnerr,bowlingc,grayp
## %sudo_c_dev  ALL=ALL
## %sudo_c_dev  ALL=(ALL) ALL
## sudo_c_dev:!:1555:
