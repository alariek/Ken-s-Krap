#! /usr/bin/bash
##set -x
for i in `cat /home/alariek/scripts/svr_list`
do
ssh "$i" hostname>> /home/alariek/scripts/oslevel.out; ssh "$i" oslevel -s >> /home/alariek/scripts/oslevel.out
done
