#!/usr/bin/ksh

for name in `cat $1`
do
        grep -w $name /etc/yp/passwd >>locked_$2.full_info

done
