#!/usr/bin/ksh

for name in `cat $1`
do
grep -w $name /etc/yp/passwd > /dev/null
        if [ $? -eq 0 ]
  then
        grep -w $name /etc/yp/passwd >>locked_$2.full_info

else
        echo "$name is not in passwd" >>locked_$2.full_info

fi
done
