#!/usr/bin/ksh

for name in `cat $1`
do
	grep -w $name /home/alariek/clt_nis/7c3_group >> 7c3_gid.out
done
