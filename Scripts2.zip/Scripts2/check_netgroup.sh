#!/usr/bin/ksh


for name in `cat $1`
do
	grep -w $name /etc/yp/netgroup > /dev/null
	if [ $? -eq 0 ]
  then

    echo "$name is in netgroup file" >> locked_netgrp_check.out

  else
   echo "" >> locked_netgrp_check.out
	
fi
done
