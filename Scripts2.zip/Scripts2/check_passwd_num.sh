#!/usr/bin/ksh
#set -x

for name in `cat $1`
do
        grep -w $name /etc/yp/passwd > /dev/null
        if [ $? -eq 0 ]
  then grep -w $name /etc/yp/passwd |awk -F":" '{print $1, " - ", $3}' >> dup_num.list
       # else
       # echo "$name is not in passwd" >>locked_passwd_check.out
fi
done
