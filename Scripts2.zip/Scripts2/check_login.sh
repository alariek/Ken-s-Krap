#!/usr/bin/ksh
## set -x

host=`hostname`

for name in `cat $1`
do
        /usr/bin/last |grep -w $name  > /dev/null
        if [ $? -eq 0 ]
  then

    echo "$name has logged in" >> $host-login-check.out

fi
done
