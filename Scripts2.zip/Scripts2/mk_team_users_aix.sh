useradd -u 4562 -g 5000 -d /home/melchert -m -c "Trent Melcher - ACI System Administrator" melchert
echo 'melchert:Welcome2ACI' |chpasswd -c
useradd -u 4564 -g 5000 -d /home/garrettg -m -c "Garry Garrett - ACI System Administrator" garrettg
echo 'garrettg:Welcome2ACI' |chpasswd -c
useradd -u 11808 -g 5000 -d /home/rossid -m -c "Dean Rossi - ACI System Administrator" rossid
echo 'rossid:Welcome2ACI' |chpasswd -c
useradd -u 4680 -g 5000 -d /home/mehars -m -c "Snehal Mehar - ACI System Administrator" mehars
echo 'mehars:Welcome2ACI' |chpasswd -c
