#!/usr/bin/ksh
#set -x

for name in `cat $1`
do
        grep -w $name /etc/yp/shadow > /dev/null
        if [ $? -eq 0 ]
  then
	grep -w $name /etc/yp/shadow >> locked_shadow.out

	else
	echo "$name is not in shadow" >>locked_shadow.out
fi
done
