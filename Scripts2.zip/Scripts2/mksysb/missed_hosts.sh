#!/usr/bin/ksh


#set -x

LOG="/tmp/mksysb_out_$$.log"

BLOG="/tmp/mksysb_error_$$.log"


echo "---------------------------------------------" >> ${LOG}

echo "---------------------------------------------" >> ${BLOG}

echo "START OF MKSYSB BACKUP" >> ${LOG}

echo "ERRORS IN PROCESSING" >> ${BLOG}


for h in `cat /usr/local/bin/missed.hosts`
do

  echo "" >> ${LOG}

  date >> ${LOG}

  ho=`echo $h | awk -F ':' '{ print $1 }'`    #Host name
  jo=`echo $h | awk -F ':' '{ print $2 }'`    #Netvault Job number

  pho=`printf "%-15s" "${ho}"`

  echo "Start \tmksysb for $ho, Netvault job $jo"  >> ${LOG}

  /usr/local/bin/mksysb_host.sh ${ho} ${jo} >> ${LOG} 2>&1

  r=$?

  echo "Finish\tmksysb for $ho, Return code ${r}" >> ${LOG}

  date >> ${LOG}

  echo "" >> ${LOG}


  if [ $r -ne 0 ]
  then

    echo "${pho}\tfailed. Return code ${r}" >> ${BLOG}

  fi

done


echo "END OF MKSYSB BACKUP" >> ${LOG}

echo "---------------------------------------------" >> ${LOG}

echo "END OF ERRORS IN PROCESSING" >> ${BLOG}

echo "---------------------------------------------" >> ${BLOG}


cat ${BLOG}

cat ${LOG}


#rm ${LOG}

#rm ${BLOG}


exit 0
