#!/usr/bin/ksh

#set -x



LOG="/tmp/mksysb_out_$$.log"

BLOG="/tmp/mksysb_error_$$.log"


echo "---------------------------------------------" >> ${LOG}

echo "---------------------------------------------" >> ${BLOG}

echo "START OF MKSYSB BACKUP" >> ${LOG}

echo "ERRORS IN PROCESSING" >> ${BLOG}


for h in TCCVSDB01V TCCVSPAPP01V TCCVSPAPP02V TCCVSPRPT01V TCCVSPRPT02V TCCVSPRPT03V TCCVSPRPT04V
 TCCVSPBAT01V TCCVSPWEB01V TCCVSPWEB02V


#for h in `cat /usr/local/bin/host_list`

  do

  echo "" >> ${LOG}

  date >> ${LOG}

  ho=`echo $h`

  pho=`printf "%-15s" "${ho}"`

  echo "Start \tmksysb for $ho"  >> ${LOG}

  echo "\t /usr/local/bin/mksysb_host.sh ${ho}" >>${LOG} 2>&1

  /usr/local/bin/mksysb_host.sh ${ho} >> ${LOG} 2>&1
  r=$?

  echo "Finish\tmksysb for $ho, Return code ${r}" >> ${LOG}

  date >> ${LOG}

  echo "" >> ${LOG}


  if [ $r -ne 0 ]
  then

    echo "${pho}\tfailed. Return code ${r}" >> ${BLOG}

  fi

done


echo "END OF MKSYSB BACKUP" >> ${LOG}

echo "---------------------------------------------" >> ${LOG}

echo "END OF ERRORS IN PROCESSING" >> ${BLOG}

echo "---------------------------------------------" >> ${BLOG}


cat ${BLOG}

cat ${LOG}


#rm ${LOG}

#rm ${BLOG}


exit 0
