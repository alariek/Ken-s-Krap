#!/usr/bin/ksh


if [ $# -ne 1 ]
then

  echo "Usage $0 hostname"
 
  exit 1

fi


LOG="/tmp/mksysb_host.$$"


catexit() {
  rc=$1
  cat ${LOG}
  rm ${LOG}
  exit ${rc}
}


host=$1
host_list=`lsnim ${host}`


if [ $? -ne 0 ]
then

  echo "FAILED: ${host} is unknown to NIM. I'm bailing." >> ${LOG}

  catexit 2

fi


## Check host for directory, clean out old file if there

#rm -rf /export/images/backup/${hosts} >> ${LOG} 2>$1

#mkdir -p /export/images/backup/${host} >> ${LOG} 2>&1


## create mksysb of host
  
d=`date +"%m_%d_%Y"
`
echo "STATUS: Starting mksysb." >> ${LOG}
echo "STATUS: Executing \
"nim -o define -t mksysb -a server=master -a source=${host} \
	-a mk_image=yes -a comments="${host} cold restore mksysb ${d}" \
	-a location="/export/images/backup/${host}/backup_${d}.mksysb" \
	${host}_${d}"" >> ${LOG}

/usr/sbin/nim -o define -t mksysb -a server=master -a source=${host} \

    -a mk_image=yes -a comments="${host} cold restore mksysb ${d}" \

    -a location="/export/images/backup/${host}/backup_${d}.mksysb" \

    ${host}_${d} > /dev/null 2>&1
nim_rc=$?

echo "STATUS: Return code from nim command ${nim_rc}" >> ${LOG}
if [ ${nim_rc} -ne 0 ]
then

  echo "FAIL: mksysb failed with ${nim_rc}: [ ${nim_out} ]" >> ${LOG}

  catexit 3

else
  echo "STATUS: Finished mksysb" >> ${LOG}

fi


## check size

ls -al /export/images/backup/${host}/backup_${d}.mksysb >> ${LOG} 2>&1
