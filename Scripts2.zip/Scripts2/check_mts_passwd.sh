#!/usr/bin/ksh
#set -x

echo "---------------------------------">> mts_nis_check.out
echo "From $1">> locked_passwd_check.out
echo "---------------------------------">> mts_nis_check.out

for name in `cat $1`
do
        grep -w $name /home/alariek/nis_cleanup/passwd.oma3nisl1 > /dev/null
        if [ $? -eq 0 ]
  then
	grep -w $name /home/alariek/nis_cleanup/passwd.oma3nisl1 |awk -F":" '{print $1, " - ", $5}' >> mts_nis_check.out

	else
	echo "$name is not in  MTS passwd" >>mts_nis_check.out

fi
done
