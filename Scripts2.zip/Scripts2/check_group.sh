#!/usr/bin/ksh

for name in `cat $1`
do
	grep -w $name /etc/yp/group > /dev/null
	if [ $? -eq 0 ]
  then

    echo "$name is in group file" >> locked_grp_check.out

  else
   echo "" >> locked_grp_check.out
	
fi
done
