#!/usr/bin/ksh
#set -x

for name in `cat $1`
do
        grep -w $name ./f5n2_nis.passwd > dup_num2.list
#        if [ $? -eq 0 ]
#  then grep -w $name ./f5n2_nis.passwd |awk -F":" '{print $1, " - ", $3}' >> dup_num2.list
#       # else
#       # echo "$name is not in passwd" >>locked_passwd_check.out
#fi
done
