#!/usr/bin/ksh
##set -x

host=`hostname`

for name in `cat $1`
do
        /usr/bin/ps -ef |grep -w $name  > /dev/null
        if [ $? -eq 0 ]
  then

    echo "$name has processes running" >> $host-ps-check.out

fi
done
