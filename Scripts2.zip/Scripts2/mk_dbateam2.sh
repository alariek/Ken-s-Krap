useradd -u 111800 -g db2admin -d /home/kocikk -m -c "Keith Kocik" kocikk
echo Welcome2ACI |passwd kocikk --stdin
useradd -u 111925 -g db2admin -d /home/vazquezj -m -c "Jason Vazquez <jason.vazquez@aciworldwide.com>" vazquezj
echo Welcome2ACI |passwd vazquezj --stdin
useradd -u 4715 -g db2admin -d /home/joshia -m -c "Ambarish Joshi <ambarish.joshi@aciworldwide.com>" joshia
echo Welcome2ACI |passwd joshia --stdin
useradd -u 111815 -g db2admin -d /home/kumars -m -c "Satish Kumar <satish.kumar@aciworldwide.com>" kumars
echo Welcome2ACI |passwd kumars --stdin

useradd -u 111800 -g sudo_dba_full -d /home/kocikk -m -c "Keith Kocik" kocikk
echo Welcome2ACI |passwd kocikk --stdin
useradd -u 111925 -g sudo_dba_full -d /home/vazquezj -m -c "Jason Vazquez <jason.vazquez@aciworldwide.com>" vazquezj
echo Welcome2ACI |passwd vazquezj --stdin
useradd -u 4715 -g sudo_dba_full -d /home/joshia -m -c "Ambarish Joshi <ambarish.joshi@aciworldwide.com>" joshia
echo Welcome2ACI |passwd joshia --stdin
useradd -u 111815 -g sudo_dba_full -d /home/kumars -m -c "Satish Kumar <satish.kumar@aciworldwide.com>" kumars
echo Welcome2ACI |passwd kumars --stdin
useradd -u 6385  -g sudo_dba_full -d /home/scottg -m -c "Greg Scott <greg.scott@aciworldwide.com>" scottg
echo Welcome2ACI |passwd scottg --stdin


## sudo_dba_full:!:99997:kocikk,vazquezj,joshia,kumars
## %sudo_dba_full ALL=(ALL) ALL
# kumars  ALL=(ALL) ALL
# joshia  ALL=(ALL) ALL
# vazquezj ALL=(ALL) ALL
# kocikk ALL=(ALL) ALL
