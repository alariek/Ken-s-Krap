#!/usr/bin/ksh
#set -x
for ip in `cat $1`
do
	nslookup $ip  |grep name >> lookup.out
done
