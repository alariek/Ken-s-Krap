#! /usr/bin/bash
set -x
for i in `cat /home/alariek/scripts/rhel_ac_list`
do
ssh "$i" grep exclude /etc/yum.conf >> excl_rhel_ac.out
done
