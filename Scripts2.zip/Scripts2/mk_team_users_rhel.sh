useradd -u 4562 -s /bin/bash -g 100 -d /home/melchert -m -c "Trent Melcher - ACI System Administrator" melchert
chage -d 0 melchert
echo Welcome2ACI |passwd melchert --stdin
useradd -u 4564 -s /bin/bash -g 100 -d /home/garrettg -m -c "Garry Garrett - ACI System Administrator" garrettg
chage -d 0 garrettg
echo Welcome2ACI |passwd garrettg --stdin
useradd -u 111859 -s /bin/bash -g 100 -d /home/denardl -m -c "Leon Denard - ACI System Administrator" denardl
chage -d 0 denardl
echo Welcome2ACI |passwd denardl --stdin
useradd -u 11808 -s /bin/bash -g 100 -d /home/rossid -m -c "Dean Rossi - ACI System Administrator" rossid
chage -d 0 rossid
echo Welcome2ACI |passwd rossid --stdin
useradd -u 6500 -s /bin/bash -g 100 -d /home/vaichalv -m -c "Vivek Vaichal - ACI System Administrator" vaichalv
chage -d 0 vaichalv
echo Welcome2ACI |passwd vaichalv --stdin
useradd -u 4680 -s /bin/bash -g 100 -d /home/mehars -m -c "Snehal Mehar - ACI System Administrator" mehars
chage -d 0 mehars
echo Welcome2ACI |passwd mehars --stdin
