#!/usr/bin/ksh

#set -x

## The variables
NAME=`uname -n`
#VG_LIST=`lsvg`

##Get hostname
echo "The output will be in a file called $NAME.conf"
echo "Getting initial information for $NAME."
echo "Configuration information for $NAME" > $NAME.conf

## Get OS level
echo "OS Level =`uname -srv`" >> $NAME.conf
echo "" >> $NAME.conf

## Get mounted file systems
df -h >> $NAME.conf
echo "" >> $NAME.conf

## List disks
echo "Presented disks"  >> $NAME.conf
lspv  >> $NAME.conf
echo "" >> $NAME.conf

## List VGs and LVs
echo "Collecting VG and LV information"
echo "VG Names" >> $NAME.conf
lsvg >> $NAME.conf
echo "" >> $NAME.conf
for vgname in $VG_LIST;
	do
	echo "---$vgname Information---"  >> $NAME.conf
	lsvg $vgname >>$NAME.conf
	lsvg -l $vgname >>$NAME.conf
	echo "" >> $NAME.conf
done
echo "" >> $NAME.conf

## Hardware information
echo "Getting hardware information"
echo "Hardware and device information" >> $NAME.conf
echo "" >> $NAME.conf
lsdev >> $NAME.conf
echo "" >> $NAME.conf
prtconf >> $NAME.conf

echo "Finished collecting information for $NAME"
