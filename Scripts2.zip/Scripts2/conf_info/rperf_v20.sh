#!/usr/bin/ksh93
# rperf version 19  date October 2012
# No restrictions, copy and use at will, this is just sample code.
# No warrentee given or implied.
# Numbers taken from Power Systems Facts and Features document easily found on the WWW
# set LANG to ensure "." decimal place handling
export LANG=C

machine=`lsattr -El sys0 -a modelname -F value`
cpus=`lsdev -Cc processor | grep Available | wc -l | sed 's/ //g'`
procstr=`lsdev -Cc processor | head -1 | cut -d' ' -f1`
proctype=`lsattr -El $procstr | awk '/^type/ {print $2}'`
Hz=`lsattr -El ${procstr%% *} -a frequency -F value`

# Ensure that procspeed is not null, since the conversion to MHz below will
# cause the script to exit with an error if null.
if [[ ! -z $Hz ]]
then
    # Convert Hz to MHz, and round up or down
    if (( ($Hz%1000000) >= 500000 ))
    then
    (( MHz=($Hz/1000000) + 1 ))
    else
    (( MHz=($Hz/1000000) ))
    fi
else
	echo MHz rating is not available, exiting
	exit 2
fi

# break the MHz in to the first two digits (enough for the lookup) and the rest
dd=${MHz:0:2}
ff=${MHz:2:9}

# This first attempt does not round up the lower digits!
#  ff=${ff//[0-9]/0}
# so below we round down, round up and round to 50

if(( $ff < 10 ))  # if below 10 i.e.  01 and 09 round down
then
	ff=${ff//[0-9]/0}
elif(( $ff > 90 ))  # if bigger than 90 round up
then
	ff=${ff//[0-9]/0}
	let dd=$dd+1
elif(( $ff > 40 ))
then
	if(( $ff < 60 )) # near 50 so make it 50
	then
		ff=50
	fi
fi

roundedMHz=$dd$ff
# Debug and testing machines other than the current one
# Set shell variables LOOKUP and CPUS, examples below
#	export LOOKUP=IBM,9119-FHB_4000_256
#	export CPUS=255
#	export LOOKUP=IBM,9110-51A_1900_2
#	export CPUS=2
#	export LOOKUP=IBM,9109-RMD_3400_48
#	export CPUS=48
#
if [ "$LOOKUP" == "" ] 
then
	lookup=${machine}_${roundedMHz}_${cpus}
else
	echo rperf Debug mode using your shell variable LOOKUP 
	lookup=$LOOKUP
	echo LOOKUP=$lookup
	debug=1
fi
if [ "$CPUS" != "" ] 
then
	echo rperf Debug mode using your shell variable CPUS 
	cpus=$CPUS
	echo CPUS=$cpus
fi

if [ "$1" == "-?" ]
then
echo "rperf -v -?"
echo -v = verbose mode
echo -? = this output
echo rperf outputs the performance number of the current machine or LPAR
echo "either Relative Performance (rPerf)"
echo " or Relative OLTP (roltp)"
echo Depending on the age of the machine.
echo There is no simple way to convert from roltp to rPerf - sorry.
echo
echo If it says estimated then it is NOT an offical number
echo LPARs the number may be estimated but it is a simple maths calculation
echo i.e. if we have the offical number for 4 CPUs then 1 CPU is simply
echo a fourth - this will be an under estimate.
echo
echo If you find bugs or missing information please let us know.
echo Perferred mechanism found at http://www.ibm.com/systems/p/community/ 
echo and AIX Performance Tools Forum
echo e-mail to nag@uk.ibm.com
exit
fi

if [ "$1" == "-v" ]
then
verbose=1
echo Information is from public documents from www.ibm.com
echo -- - System p Performance Report
echo -- - System p Facts and Features Document
echo -- - Power Systems Facts and Features Document
if [ "$debug" != "1" ] # if in debug mode outputing the current machine is confusing
then
	echo Machine=$machine MHz=$MHz Rounded-MHz=$roundedMHz CPUs=$cpus CPUType=$proctype
fi
echo lookup $lookup
fi
# below is the default but changed to roltp or estimated where necessary
units=rPerf

calculate()
{
if [ "$verbose" == "1" ]
then
	echo calculate cpus=$cpus from $* 
fi
	if [ "$1" == "" ]
	then 
		return
	fi
	if((cpus==$1))
	then
		rating=$2
		return
	fi
	if((cpus<$1))
	then
		let rating=$2/$1*$cpus; 
		estimated="estimated"
	fi
} 

matchup()
{
# Debug echo matchup 1=$1 2=$2 3=$3 4=$4 5=$5 6=$6 7=$7 8=$8 9=$9 10=${10} 11=$11 12=$12 13=$13 14=$14 arguments= $#
if [ "$verbose" == "1" ]
then
	echo matchup $*
fi
	rating=0
	if(($#>=2)) then calculate $1 $2 ; fi;
	if((rating != 0)) then return; fi;
	if(($#>=4)) then calculate $3 $4 ; fi;
	if((rating != 0)) then return; fi;
	if(($#>=6)) then calculate $5 $6 ; fi;
	if((rating != 0)) then return; fi;
	if(($#>=8)) then calculate $7 $8 ; fi;
	if((rating != 0)) then return; fi;
	if(($#>=10)) then calculate $9 ${10} ; fi;
	if((rating != 0)) then return; fi;
	if(($#>=12)) then calculate ${11} ${12} ; fi;
	if((rating != 0)) then return; fi;
	if(($#>=14)) then calculate ${13} ${14} ; fi;
	if((rating != 0)) then return; fi;
	if(($#>=16)) then calculate ${15} ${16} ; fi;
	if((rating != 0)) then return; fi;
	if(($#>=18)) then calculate ${17} ${18} ; fi;
	if((rating != 0)) then return; fi;
	if(($#>=20)) then calculate ${19} ${20} ; fi;
}

case $lookup in
	IBM,7043-150_250_1) rating=0.18;;
	IBM,7043-150_375_1) rating=0.26;;
	IBM,7043-260_200_1) rating=10.5; units=roltp ;;
	IBM,7043-260_200_2) rating=21.0; units=roltp ;;
	IBM,7044-170_333_1) rating=0.58 ;;
	IBM,7044-170_400_1) rating=0.73 ;;
	IBM,7044-170_450_1) rating=0.79 ;;
	IBM,7044-270_375_1) rating=1.00 ;;
	IBM,7044-270_375_2) rating=1.92 ;;
	IBM,7044-270_375_3) rating=2.55 ;;
	IBM,7044-270_375_4) rating=3.47 ;;
	IBM,7044-270_375_2) rating=1.99 ;;
	IBM,7044-270_375_4) rating=3.59 ;;
	IBM,7044-270_450_2) rating=2.27 ;;
	IBM,7044-270_450_4) rating=4.01 ;;

	IBM,7025-F80_450_1)  rating=23.0; units=roltp ;;
	IBM,7025-F80_450_2)  rating=50.0; units=roltp ;;
	IBM,7025-F80_450_4)  rating=87.7; units=roltp ;;
	IBM,7025-F80_500_6)  rating=111.9; units=roltp ;;
	IBM,7025-F80_600_1)  rating=32.3; units=roltp ;;
	IBM,7025-F80_600_2)  rating=69.0; units=roltp ;;
	IBM,7025-F80_600_4)  rating=117.0; units=roltp ;;
	IBM,7025-F80_500_6)  rating=191.2; units=roltp ;;

	IBM,7025-6F0_450_1) rating=0.93 ;;
	IBM,7025-6F0_450_2) rating=2.02 ;;
	IBM,7025-6F0_450_4) rating=3.55 ;;
	IBM,7025-6F0_600_1) rating=1.26 ;;
	IBM,7025-6F0_600_2) rating=2.69 ;;
	IBM,7025-6F0_600_4) rating=4.57 ;;
	IBM,7025-6F0_750_1) rating=1.91 ;;
	IBM,7025-6F0_750_2) rating=3.49 ;;
	IBM,7025-6F0_750_4) rating=5.85 ;;
	IBM,7025-6F1_450_1) rating=0.93 ;;
	IBM,7025-6F1_450_2) rating=2.02 ;;
	IBM,7025-6F1_450_4) rating=3.55 ;;
	IBM,7025-6F1_668_6) rating=7.46 ;;
	IBM,7025-6F1_600_1) rating=1.26 ;;
	IBM,7025-6F1_600_2) rating=2.69 ;;
	IBM,7025-6F1_600_4) rating=4.57 ;;
	IBM,7025-6F1_750_1) rating=1.91 ;;
	IBM,7025-6F1_750_2) rating=3.49 ;;
	IBM,7025-6F1_750_4) rating=5.85 ;;
	IBM,7025-6F1_750_6) rating=8.23 ;;

	IBM,7017-S80_450_6) rating=161.7; units=roltp ;;
	IBM,7017-S80_450_12) rating=306.7; units=roltp ;;
	IBM,7017-S80_450_18) rating=428.7; units=roltp ;;
	IBM,7017-S80_450_24) rating=533.3; units=roltp ;;
	IBM,7017-S80_600_6) rating=219.0; units=roltp ;;
	IBM,7017-S80_600_12) rating=416.0; units=roltp ;;
	IBM,7017-S80_600_18) rating=583.3; units=roltp ;;
	IBM,7017-S80_600_24) rating=736.0; units=roltp ;;
	
	IBM,7040-681_1100_*) matchup 8 18.02 16 34.66 24 48.11 32 60.66  0 0 ;;
	IBM,7040-681_1300_*) matchup 8 21.20 16 40.92 24 56.46 32 71.44 0 0 ;;
	IBM,7040-681_1500_*) matchup 8 24.18 16 46.79 24 64.99 32 81.95 0 0 ;;
	IBM,7040-681_1700_*) matchup 8 27.11 16 52.45 24 16.29 32 92.19 0 0 ;;
	IBM,7040-681_1900_*) matchup 8 30.63 16 59.26 24 82.32 32 104.17 0 0 ;;

	IBM,9115-505_1500_2) rating=9.13 ;;

	# The 1 CPU zero L2 cache model has a low rPerf 
	#- here we assume it is not popular and you have a an 1 VP CPU LPAR
	# IBM,9115-505_1650_1) rating=3.51 ;;
	IBM,9115-505_1650_1) let rating=9.86/2; estimated="estimated i.e. assuming its not the 1 CPU with zero L2 model" ;;

	IBM,9115-505_1650_*) matchup 2 9.86 4 20.25 0 0 ;;
	IBM,9115-505_1900_*) matchup 1 4.10 2 11.49 0 0 ;;

	IBM,9115-505_2100_*) calculate 2 12.46 ;;

	IBM,9110-51A_1500_*) matchup 1 3.25 2 9.13 4 18.75 ;;
	IBM,9110-510_1650_*) matchup 1 5.24 2 9.86 4 20.25 ;;

	IBM,9110-51A_1900_*) matchup 1 6.11 2 11.49;;

	IBM,9110-51A_2100_*) matchup 1 6.63 2 12.46 0 0 ;;
	IBM,9111-520_1500_*) matchup 1 3.25 2 9.13 0 0 ;;
	IBM,9111-520_1650_*) calculate 2 9.86 ;;
	IBM,9131-52A_1650_*) matchup 1 3.62 2 10.15 4 20.25 ;;
	IBM,9131-52A_1900_*) calculate 2 11.16 ;;
	IBM,9131-52A_1500_*) calculate 4 18.75 ;;
	IBM,9131-52A_2100_*) matchup 1 6.63 2 12.46 0 0 ;;
	IBM,9133-55A_1500_*) matchup 4 18.20 8 34.46 0 0;;
	IBM,9133-55A_1650_*) matchup 2 10.15 4 20.25 8 38.34 ;;
	IBM,9133-55A_1900_*) matchup 2 11.16 4 22.26 0 0 ;;
	IBM,9133-55A_2100_*) matchup 2 12.46 4 24.86 0 0;;
	IBM,9113-550_1500_*) matchup 1 3.25 2 9.13 4 18.20 ;;
	IBM,9113-550_1650_*) matchup 2 9.86 4 19.66 0 0 ;;
	IBM,9116-561_1500_*) matchup 4 18.75 8 35.50 16 65.24 ;;
	IBM,9116-561_1800_*) matchup 4 21.72 8 41.12 16 75.58 ;;
	IBM,9117-570_1500_*) matchup 2 9.13 4 18.20 8 34.46 ;;
	IBM,9117-570_1650_*) matchup 2 9.86 4 19.66 8 37.22 12 53.43 16 68.40 ;;

	# darn we have two machines at same MHz for POWER5 and POWER5+
	IBM,9117-570_1900_*) 
	if [ $proctype == "POWER5+" ]
	then
		matchup 2 12.27 4 24.18 8 46.36 12 66.55 16 95.96
	else
		matchup 2 11.16 4 22.26 8 42.14 12 60.50 16 77.45
	fi;;

	IBM,9117-570_2200_*) 
        if [ $proctype == "POWER5+" ]
        then
		matchup 2 13.83 4 27.58 8 52.21 12 74.95 16 95.96
        else
                matchup 2 10.63 4 21.21 8 42.16 12 57.65 16 73.81
        fi;;


	IBM,9119-590_1650_*) matchup 8 41.68 16 80.86 24 16.29 32 151.72 0 0 ;;
	IBM,9119-590_2100_*) matchup 8 55.74 16 108.13 24 155.51 32 202.88 0 0 ;;
	IBM,9119-595_1650_*) matchup 16 80.86 24 116.29 32 151.72 40 182.07 48 212.41 56 242.76 64 273.10;;
	IBM,9119-595_1900_*) matchup 16 90.67 24 130.39 32 170.11 40 204.14 48 238.16 56 272.18 64 306.21;;
	IBM,9119-595_2100_*) matchup 16 108.13 24 155.51 32 202.88 40 243.46 48 284.04 56 324.61 64 365.19;;
	IBM,9119-595_2300_*) matchup 16 116.13 24 167.58 32 218.64 40 262.37 48 306.10 56 349.83 64 393.55 ;;

	# JS21 Blades
	IBM,7988-J21_2700_*) calculate 2  5.31;;
	IBM,7988-J21_2500_*) calculate 4  8.72;;

	# POWER6
	# JS12 and JS22 Blades
	IBM,7998-60X_3800_*) calculate 2 14.71;;
	IBM,7998-61X_4000_*) calculate 4 30.26;;
	# 520
	IBM,8203-E4A_4200_*) matchup 1 8.39 2 15.95 4 31.48 ;;
	# 550
	IBM,8204-E8A_3500_*) matchup 2 15.85 4 31.27 6 45.04 8 58.80;;
	IBM,8204-E8A_4200_*) matchup 2 18.38 4 36.28 6 52.24 8 68.20;;
	# 570
	IBM,9117-MMA_3500_*) matchup 2 15.85 4 31.69 8 58.95 12  83.35 16 105.75 ;;
	# POWER6 IBM,9117-MMA_4200_*) matchup 2 18.38 4 36.76 8 68.38 12  96.68 16 122.67 ;;
	# POWER6+
	IBM,9117-MMA_4200_*) matchup 4 35.50 8 64.96 16 113.68 24 153.46 32 193.25 ;;
	IBM,9117-MMA_4700_*) matchup 2 20.13 4 40.26 8 74.89 12 105.89 16 134.35 ;;
	# POWER6+
	IBM,9117-MMA_4400_*) matchup 2 19.08 4 38.16 8 70.97 12 100.35 16 127.32 ;;
	IBM,9117-MMA_5000_*) matchup 2 21.16 4 42.32 8 78.71 12 111.30 16 141.21 ;;

	# 595
	IBM,9119-FHA_4200_*) matchup 8 75.58 16 142.90 24 204.70 32 266.51 40 320.05 48 373.60 56 426.74 64 479.89 ;;
	IBM,9119-FHA_5000_*) matchup 8 87.10 16 164.67 24 235.90 32 307.12 40 368.82 48 430.53 56 491.77 64 553.01 ;;

	# Older POWER4 and POWER4+ Models added in rperf v7
	IBM,7028-6C4_1000_*) matchup 1 1.72 2 3.68 4 7.12 0 0 ;;
	IBM,7028-6C4_1200_*) matchup 1 2.50 2 4.00 4 8.05 0 0 ;;
	IBM,7028-6C4_1450_*) matchup 1 2.94 2 4.41 4 8.69 0 0 ;;
	IBM,7028-6E4_1000_*) matchup 1 1.72 2 3.68 4 7.12 0 0 ;;
	IBM,7028-6E4_1200_*) matchup 1 2.50 2 4.00 4 8.05 0 0 ;;
	IBM,7028-6E4_1450_*) matchup 1 2.94 2 4.41 4 8.69 0 0 ;;

	IBM,7029-6C3_1200_1) rating=2.50 ;;
	IBM,7029-6C3_1200_2) rating=4.00 ;;
	IBM,7029-6C3_1450_2) rating=4.41 ;;

	IBM,7038-6M2_1200_*) matchup 2 4.00 4 8.05 6 11.77 8 15.49 ;;
	IBM,7038-6M2_1450_*) matchup 2 4.47 4 9.12 6 13.47 8 18.67 ;;

	IBM,7039-651_1100_8) rating=12.00 ;;
	IBM,7039-651_1300_4) rating=9.05 ;;
	IBM,7039-651_1500_8) rating=21.87 ;;
	IBM,7039-651_1700_4) rating=15.22 ;;

	IBM,7040-671_1100_*) matchup 4 10.18 8 18.02 16 34.66 ;;
	IBM,7040-671_1500_*) matchup 4 13.66 8 24.18 16 46.79 ;;

	# New Addtions for rperf v8 - thanks Michael P
	# JS23 and JS43 Blades  - thanks Michel M
	IBM,7778-23X_4200_*) matchup  4 36.28  8 68.2  ;;
	# New faster CPUs for POWER6
	IBM,8203-E4A_4700_*) matchup  2 20.13  4 39.73  ;;
	IBM,8204-E8A_5000_*) matchup  2 21.18  4 41.81  6 60.2   8 78.6  ;;
	IBM,8234-EMA_3600_*) matchup  4 31.32  8 57.3  16 100.3  ;;
	IBM,9119-FHA_4200_*) matchup  8  72.58  16 142.9  24 204.7   32 266.51  40 320.05  48 373.6  56 426.74  64 479.89 ;;
	IBM,9119-FHA_5000_*) matchup 16 164.67  24 235.9  32 307.12  40 368.82  48 430.53  56 491.77  64 553.01  ;;

	# POWER7 Power 750 from May 2010
	IBM,8233-E8B_3000_*) matchup  8  81.24  16 155.99  24 224.23  32 292.47  ;;
	IBM,8233-E8B_3300_*) matchup  8  86.99  16 167.01  24 240.08  32 313.15  ;;
	IBM,8233-E8B_3500_*) matchup  32 331.06  ;;
	# POWER7 Power 750 April 2011
	IBM,8233-E8B_3200_*) matchup  8  85.29  16 163.75  24 235.39  32 307.03  ;;
	IBM,8233-E8B_3220_*) matchup  8  85.29  16 163.75  24 235.39  32 307.03  ;;
	IBM,8233-E8B_3600_*) matchup  8  93.05  16 178.65  24 256.81  32 334.97  ;;
	IBM,8233-E8B_3700_*) matchup  4 52.90 6 76.71 8 101.67 12 146.00 16 190.44 18 211.71 24 276.14  ;;
	# POWER7+ Power 750 Feb 2013
	IBM,8408-E8D_3500_*) matchup  8  104.5 16 197.0 24 275.9 32 354.9  ;;
	IBM,8408-E8D_4000_*) matchup  8  117.1 16 220.7 24 309.2 32 397.7  ;;
	# POWER7+ Power 760 Feb 2013
	IBM,9109-RMD_3100_*) matchup  12  142.1 24 264.8 36 370.7 48 476.7  ;;
	IBM,9109-RMD_3400_*) matchup  12  151.4 24 282.1 36 395.0 48 507.8  ;;

	# Power 755 assuming 750 rPerf numbers are OK
	IBM,8236-E8C_3300_*) matchup  8  86.99  16 167.01  24 240.08  32 313.15  ;;
	# Power 755 June 2012 - no values present yet for 3.6 GHz version.
	# Made ESTIMATION based on number above 36/33 * 313.15 = 341.62
	IBM,8236-E8C_3600_*) matchup  32 341.62  ;;  # ESTIMATE

	# Power 770 
	IBM,9117-MMB_3100_*) matchup  16 165.30 32 306.74 48 443.06 64 579.39 ;;
	IBM,9117-MMB_3500_*) matchup  12 140.75 24 261.19 36 377.26 48 493.37 ;;
	# Power 770 C models - Nov 2011
	IBM,9117-MMC_3300_*) matchup  16 173.1 32 321.2 48 464.0 64 606.8 ;;
	IBM,9117-MMC_3720_*) matchup  12 147.5 24 273.7 36 395.4 48 517.0 ;;
	# Power 770 D models - Oct 2012
	IBM,9117-MMD_3800_*) matchup  16 219.3 32 410.8 48 570.1 64 729.3 ;;
	IBM,9117-MMD_4200_*) matchup  12 184.2 24 345.1 36 478.9 48 612.7 ;;

	# Power 780
	IBM,9179-MHB_3860_*) matchup 16 195.45  32 362.7   48 523.89  64 685.09  ;;
	IBM,9179-MHB_4140_*) matchup  8 115.16  16 226.97  24 326.24  32 425.5   ;;
	IBM,9179-MHB_4150_*) matchup  8 115.16  16 226.97  24 326.24  32 425.5   ;; # marketing think it is 4.14 GHz but the machine say 4.15 GHz
	# Power 780 C models - Nov 2011
	IBM,9179-MHC_3440_*) matchup 24 253.3  48 443.3  72 696.6  96 886.6 ;;
	IBM,9179-MHC_3920_*) matchup 16 197.6  32 366.6  48 529.6  64 692.5 ;;
	IBM,9179-MHC_4150_*) matchup  8 115.9  16 227.0  24 326.2  32 425.5 ;; 
	IBM,9179-MHC_4140_*) matchup  8 115.9  16 227.0  24 326.2  32 425.5 ;; # June 2012 - Copied from 4.15 GHz version.
	# Power 780 D models - Oct 2012 - no more Turbo-Core
	IBM,9179-MHD_3700_*) matchup 32 383.9  64 690.1  96 1151.6 128 1380.2 ;;
	IBM,9179-MHD_4400_*) matchup 16 245.7  32 460.3  48 638.7   64 817.1 ;;

	# POWER7 Blades April 2010
	IBM,8406-70Y_3000*) calculate 4 45.13 ;; #PS700
	IBM,8406-71Y_3000*) matchup   8 81.24 16 154.36 ;; # PS701 and 702

	# POWER7 Blades April 2010
	IBM,7891-73X_2400*) calculate   16 134.11 ;; # PS703 
	IBM,7891-74X_2400*) calculate   32 251.45 ;; # PS704

	# POWER7 Power 710 and 730 August 2010
	IBM,8231-E2B_3000*) matchup   4 45.13 8 86.66 ;; 
	IBM,8231-E2B_3700*) matchup   6 76.69 8 101.62 12 147.24 ;; 
	IBM,8231-E2B_3550*) matchup   8 91.96 16 176.57 ;; 
	# POWER7 Power 710 and 730 C models  - Nov 2011
        IBM,8231-E1C_3000*) matchup   4 45.13 ;;
        IBM,8231-E1C_3700*) matchup   6 76.69 ;;
        IBM,8231-E1C_3550*) matchup   8 91.96 ;;
	IBM,8231-E2C_3000*) matchup   4 45.13 8 86.66 ;; 
	IBM,8231-E2C_3700*) matchup   6 76.69 8 101.62 12 147.24 ;; 
	IBM,8231-E2C_3550*) matchup   8 91.96 16 176.57 ;; 
	# POWER7+ Power 710 and 730 D models  - Feb 2013
	IBM,8231-E1D_3600*) matchup   4 53.9 ;; 
	IBM,8231-E1D_4200*) matchup   6 90.6 8 115.5 ;; 
	IBM,8231-E2D_4300*) matchup   8 120.4 ;;
	IBM,8231-E2D_4200*) matchup   12 176.6 16 223.1 ;;
	IBM,8231-E2D_3600*) matchup   16 197.8 ;;

	# POWER7 Power 720 and 740 August 2010
	IBM,8202-E4B_3000*) matchup   4 45.13 6 65.52 8 81.24 ;; 
	IBM,8202-E4B_3300*) matchup   4 48333 8 92.79 ;; 
	IBM,8202-E4B_3700*) matchup   4 52.93 8 101.62 12 147.24 ;; # available in 4 or 6 core versions with some crossover 
	IBM,8202-E4B_3550*) matchup   8 91.96 16 176.57 ;; 
        # POWER7 Power 740 Express - October 2011
        IBM,8205-E6B_3300*) matchup   4 48.33 8 92.79 ;;
        IBM,8205-E6B_3700*) matchup   4 52.93 6 76.69 8 101.62 12 147.24 ;;
        IBM,8205-E6B_3550*) matchup   8 91.96 16 176.57 ;;
        IBM,8205-E6C_3300*) matchup   4 48.33 8 92.79 ;;
        IBM,8205-E6C_3700*) matchup   4 52.93 6 76.69 8 101.62 12 147.24 ;;
        IBM,8205-E6C_3550*) matchup   8 91.96 16 176.57 ;;
	# Power 720 and 740 C models - same rPerf and B models - Nov 2011
	IBM,8202-E4C_3000*) matchup   4 45.13 6 65.52 8 81.24 ;; 
	IBM,8202-E4C_3300*) matchup   4 48.33 8 92.79 ;; 
	IBM,8202-E4C_3700*) matchup   4 52.93 6 76.69 8 101.62 12 147.24 ;; # available in 4 or 6 core versions with some crossover 
	IBM,8202-E4C_3550*) matchup   8 91.96 16 176.57 ;; 
	# POWER7+ Power 720 and 740 D models - Feb 2013
	IBM,8202-E4D_3600*) matchup   4 53.9 6 79.5 8 102.4 ;; 
	IBM,8202-E6D_4200*) matchup   6 90.6 8 115.5 12 176.6 18 233.1 ;; # available in 6 or 8 core versions with some crossover
	IBM,8202-E6D_3600*) matchup   8 102.4 16 197.7 ;; 

	# POWER7 Power 795  August 2010
	IBM,9119-FHB_3700*) matchup 24 273.51  192 2188.08 ;; # 6 core
	IBM,9119-FHB_4000*) matchup 32 372.27  256 2978.16 ;; # 8 core
	IBM,9119-FHB_4250*) matchup 24 347.36 48 694.71  128 1852.56 ;; #Turbo core

	*) rating=unknown; units=unknown;;
esac

if (( $rating == 0 ))
then 
	rating=unknown
	units=unknown
fi
printf "%.2f %s %s\n" $rating $units $estimated
