#!/usr/bin/ksh

#set -x

## The variables
NAME=`uname -n`
VG_LIST=`vgdisplay -s`

##Get hostname
echo "The output will be in a file called $NAME.conf"
echo "Getting initial information for $NAME."
echo "Configuration information for $NAME" > $NAME.conf

## Get OS level
more /etc/redhat-release >> $NAME.conf
echo "" >> $NAME.conf

##Get interface info
ifconfig -a >> $NAME.conf
echo "" >> $NAME.conf

## Get mounted file systems
df -h >> $NAME.conf
echo "" >> $NAME.conf

## List disks
echo "Presented disks"  >> $NAME.conf
pvdisplay  >> $NAME.conf
echo "" >> $NAME.conf

## List VGs and LVs
echo "Collecting VG and LV information"
echo "VG Names" >> $NAME.conf
vgdisplay -s >> $NAME.conf
echo "" >> $NAME.conf
vgdisplay -v >> $NAME.conf
echo "" >> $NAME.conf

## Hardware information
echo "Getting hardware information"
echo "Hardware and device information" >> $NAME.conf
echo "" >> $NAME.conf
more /proc/cpuinfo >> $NAME.conf
echo "" >> $NAME.conf
free -m >> $NAME.conf
echo "" >> $NAME.conf

echo "Finished collecting information for $NAME"
