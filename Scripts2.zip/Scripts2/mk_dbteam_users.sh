useradd -u 111701 -g dbadmin -d /home/manguale -m -c "Ed Mangual" manguale
echo Welcome2ACI |passwd manguale --stdin
useradd -u 111702 -g dbadmin -d /home/gundad -m -c "Deepak Gunda" gundad
echo Welcome2ACI |passwd gundad --stdin
useradd -u 111698 -g dbadmin -d /home/wadnerka -m -c "Ashish Wadnerkar" wadnerka
echo Welcome2ACI |passwd wadnerka --stdin
useradd -u 111799 -g dbadmin -d /home/subramaa -m -c "Arulmani Subramanian" subramaa
echo Welcome2ACI |passwd subramaa --stdin
useradd -u 4697 -g dbadmin -d /home/karales -m -c "Subhash Karale" karales
echo Welcome2ACI |passwd karales --stdin
useradd -u 4921 -g dbadmin -d /home/anandm -m -c "Maneka Anand" anandm
echo Welcome2ACI |passwd anandm --stdin
useradd -u 4751 -g dbadmin -d /home/chatteri -m -c "Indraneel Chatterjee" chatteri
echo Welcome2ACI |passwd chatteri --stdin
useradd -u 111907 -g dbadmin -d /home/jathara -m -c "Aniruddha Jathar" jathara
echo Welcome2ACI |passwd jathara --stdin
useradd -u 4711 -g dbadmin -d /home/pandep -m -c "Prasad Pande" pandep
echo Welcome2ACI |passwd pandep --stdin
useradd -u 4714 -g dbadmin -d /home/agrawals -m -c "Saurabh Agrawal" agrawals
echo Welcome2ACI |passwd agrawals --stdin
useradd -u 4750 -g dbadmin -d /home/pawars -m -c "Sharad Pawar" pawars
echo Welcome2ACI |passwd pawars --stdin
useradd -u 111800 -g dbadmin -d /home/kocikk -m -c "Keith Kocik" kocikk
echo Welcome2ACI |passwd kocikk --stdin
