#!/usr/bin/ksh

for name in `cat $1`
do
        grep -w $name /home/alariek/nis_cleanup/full_list >>removed_accts

done
