#!/usr/bin/ksh
#set -x

echo "---------------------------------">> locked_passwd_check.out
echo "From $1">> locked_passwd_check.out
echo "---------------------------------">> locked_passwd_check.out

for name in `cat $1`
do
        grep -w $name /etc/yp/passwd > /dev/null
        if [ $? -eq 0 ]
  then
	grep -w $name /etc/yp/passwd |awk -F":" '{print $1, " - ", $5}' >> locked_passwd_check.out

	else
	echo "$name is not in passwd" >>locked_passwd_check.out
fi
done
