#!/bin/ksh
/usr/local/bin/sudo /usr/sbin/psrset -c 9 10 11
/usr/local/bin/sudo /usr/sbin/psrset -c 7 8
/usr/local/bin/sudo /usr/sbin/psrset -c 12 13
/usr/local/bin/sudo /usr/sbin/psrset -c 14 15
/usr/local/bin/sudo /usr/sbin/psrset -c 16 17
/usr/local/bin/sudo /usr/sbin/psrset -c 18 19
/usr/local/bin/sudo /usr/sbin/psrset -c 20 21
/usr/local/bin/sudo /usr/sbin/psrset -c 22 23


/usr/sbin/psrset -q
