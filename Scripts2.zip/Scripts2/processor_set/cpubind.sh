#!/bin/ksh
(( j = 2))
for i in `ps -ef | grep is.exe | grep AS1V | grep -v grep | awk {'print $2'}`
do
/usr/local/bin/sudo /usr/sbin/psrset -b $j $i
((j=$j+1))
done
/usr/local/bin/sudo /usr/sbin/psrset -b 1 `ps -ef | grep ctsrvr | grep -v grep | awk {'print $2'}`
/usr/sbin/psrset -q
