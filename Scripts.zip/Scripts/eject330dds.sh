#!/usr/bin/ksh
#
# eject330dds.sh
# eject all 330 building dds tapes
#
#
echo ejecting sun1 local
mt offline
#
echo ejecting sun3 ssh
ssh acio-cissun3 "mt offline "
#
echo ejecting sun5 ssh
ssh oma3s005 "mt offline "
#
## echo ejecting sun8 ssh
## ssh acio-cissun8 "mt offline "
#
echo ejecting sun9 ssh
ssh acio-cissun9 "mt offline "
#
echo ejecting sun11 ssh
ssh acio-cissun11 "mt offline "
#
echo ejecting sun16 ssh
ssh acio-cissun16 "mt offline "
#
echo ejecting rsf50 rsh
rsh rsf50 "mt offline "
#
echo ejecting hpd330 rsh
rsh hpd330 "mt offline "
