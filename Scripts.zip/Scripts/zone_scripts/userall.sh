
mkdir /zone_root/oma3s036c1/root/home/grassib
mkdir /zone_root/oma3s036c2/root/home/grassib
mkdir /zone_root/oma3s036c3/root/home/grassib
mkdir /zone_root/oma3s036c4/root/home/grassib
mkdir /zone_root/oma3s036c5/root/home/grassib
mkdir /zone_root/oma3s036c6/root/home/grassib
mkdir /zone_root/oma3s036c7/root/home/grassib
mkdir /zone_root/oma3s036c8/root/home/grassib
mkdir /zone_root/oma3s036c9/root/home/grassib
mkdir /zone_root/oma3s036c10/root/home/grassib
mkdir /zone_root/oma3s036c11/root/home/grassib
mkdir /zone_root/oma3s036c12/root/home/grassib

chown grassib:dba /zone_root/oma3s036c1/root/home/grassib
chown grassib:dba /zone_root/oma3s036c2/root/home/grassib
chown grassib:dba /zone_root/oma3s036c3/root/home/grassib
chown grassib:dba /zone_root/oma3s036c4/root/home/grassib
chown grassib:dba /zone_root/oma3s036c5/root/home/grassib
chown grassib:dba /zone_root/oma3s036c6/root/home/grassib
chown grassib:dba /zone_root/oma3s036c7/root/home/grassib
chown grassib:dba /zone_root/oma3s036c8/root/home/grassib
chown grassib:dba /zone_root/oma3s036c9/root/home/grassib
chown grassib:dba /zone_root/oma3s036c10/root/home/grassib
chown grassib:dba /zone_root/oma3s036c11/root/home/grassib
chown grassib:dba /zone_root/oma3s036c12/root/home/grassib
