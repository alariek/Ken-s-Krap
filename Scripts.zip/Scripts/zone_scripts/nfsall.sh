cat /sysadm/zones/scripts/addnfs.txt >> /zone_root/oma3s036c1/root/etc/vfstab
cat /sysadm/zones/scripts/addnfs.txt >> /zone_root/oma3s036c2/root/etc/vfstab
cat /sysadm/zones/scripts/addnfs.txt >> /zone_root/oma3s036c3/root/etc/vfstab
cat /sysadm/zones/scripts/addnfs.txt >> /zone_root/oma3s036c4/root/etc/vfstab
cat /sysadm/zones/scripts/addnfs.txt >> /zone_root/oma3s036c5/root/etc/vfstab
cat /sysadm/zones/scripts/addnfs.txt >> /zone_root/oma3s036c6/root/etc/vfstab
cat /sysadm/zones/scripts/addnfs.txt >> /zone_root/oma3s036c7/root/etc/vfstab
cat /sysadm/zones/scripts/addnfs.txt >> /zone_root/oma3s036c8/root/etc/vfstab
cat /sysadm/zones/scripts/addnfs.txt >> /zone_root/oma3s036c9/root/etc/vfstab
cat /sysadm/zones/scripts/addnfs.txt >> /zone_root/oma3s036c10/root/etc/vfstab
cat /sysadm/zones/scripts/addnfs.txt >> /zone_root/oma3s036c11/root/etc/vfstab
cat /sysadm/zones/scripts/addnfs.txt >> /zone_root/oma3s036c12/root/etc/vfstab


mkdir /zone_root/oma3s036c1/root/dbsource
mkdir /zone_root/oma3s036c2/root/dbsource
mkdir /zone_root/oma3s036c3/root/dbsource
mkdir /zone_root/oma3s036c4/root/dbsource
mkdir /zone_root/oma3s036c5/root/dbsource
mkdir /zone_root/oma3s036c6/root/dbsource
mkdir /zone_root/oma3s036c7/root/dbsource
mkdir /zone_root/oma3s036c8/root/dbsource
mkdir /zone_root/oma3s036c9/root/dbsource
mkdir /zone_root/oma3s036c10/root/dbsource
mkdir /zone_root/oma3s036c11/root/dbsource
mkdir /zone_root/oma3s036c12/root/dbsource
