#!/bin/bash
#
# Version 1.5
# Brad Diggs and Alan Nichols
#
# The purpose of this script is to automate setting up a 
# Solaris 10 zone.
#
#set -x
######################################################################
# Initialize variables
#
PATH="/usr/bin:/bin:/usr/sbin:/sbin:/usr/sfw/bin:/opt/sfw/bin:/usr/local/bin:.:$PATH"
version='1.5'
domains=''
domainname=''
manage_services=''
zonetype='s'
roothomedir=''
rodirlist=''
rwdirlist=''
ronum=0
rwnum=0
fnum=0
snum=0
rodirs[$ronum]=''
rwdirs[$rwnum]=''
files[$fnum]=''
services[$snum]=''

######################################################################
# Define error message
#
error_message() {
   errmsg=$1
   if [ -n "$errmsg" ]
   then 
      echo "Error: $errmsg"
      echo "Use -h flag to see proper usage"
      exit 1
   fi
}

######################################################################
# Define appropriate usage
#
usage() {
   errmsg=$1
   if [ -n "$errmsg" ]; then echo "$errrmsg";fi
   echo "Usage: $0 -a <action> -n <name>
     -a <action>   = Management action
                       add - Add a zone
                       del - Delete a zone
                       list - List current zones
                       lock - Disable all un-necessary services
                       unlock - Modify the configuration of a zone
                       shutdown - Shutdown a zone
                       halt - Halt a zone
                       boot - Boot a zone
                       reboot - Reboot a zone
       -n \"<name>\" = Zone name

   Action specific usage:
     add - Add a zone
       -z \"<dir>\"          = Base directory for this zone
       -P \"<password>\"     = Unencrypted non-global zone root password
       -E \"<enc_password>\" = Encrypted non-global zone root password (cut/paste from /etc/shadow)
       -I \"<IP Address>\"   = IP Address of the non-global zone
       -i \"<interface>\"    = Network interface of the non-global zone
                               [default: first non-loopback interface listed by ifconfig]
       -t [w|s]              = Type of zone where w=Whole Root and s=Sparse [default: s]
       -r \"<gdir>|<ldir>\"  = Mount global zone directory (gdir) on a non-global zone directory (ldir) in readonly mode
       -w \"<gdir>|<ldir>\"  = Mount global zone directory (gdir) on a non-global zone directory (ldir) in read write mode
       -R \"<dir>\"          = Custom home directory for root user
       -d \"<ns1>,<ns2>,..\" = DNS Name Servers
       -D \"<domain>\"       = DNS Domain Name
       -C \"<file>\"         = File to copy from the global zone
       -s enable or disable  = Enable (unlock) or disable (lock down) operating system services
       -S \"service\"        = Service to restart after adding zone.  Special case is 'reboot' to restart all services in the zone.
       -h                    = See this usage information
       -v                    = See the version number of this script
"

   exit 1 
}

######################################################################
# Subroutine for deleting a zone
#
delete_zone() {
   zonename="$1"
   if [ -z "$zonename" ]
   then
      error_message "Must specify a zone name with the -n <name> flag"
   else
      #
      # Get necessary info to intelligently know what to clean up
      #
      zonepath=`zonecfg -z "$zonename" info zonepath 2> /dev/null | awk '{ print $2 }'`
      zonedirs=`zonecfg -z "$zonename" info fs 2> /dev/null | grep "special" | awk '{ print $2 }'`

      #
      # Make sure that the zone exists before trying to remove it.
      #
      ck4zone=`zoneadm -z "$zonename" list -v 2> /dev/null | grep "$zonename" | awk '{ print $3 }'`
      if [ -n "$ck4zone" ]
      then
         #
         # Ensure that the zone is shutdown
         #
         if [ "$ck4zone" = 'running' ]
         then
            zoneadm -z $zonename halt
         fi
         #
         # Uninstall and delete the zone
         #
         zoneadm -z $zonename uninstall -F
         zonecfg -z $zonename delete -F
         #
         # Provide info on what may need to be cleaned up
         #
         echo "With the exception of the root users's home directory, this script does"
         echo "not remove any zone data.  There may be contents within the following"
         echo "directories that you may want to manually remove."
         echo "Zone path: $zonepath"
         echo "Globally mounted zone directories:"
         echo "$zonedirs"
      else
         echo "Error: Zone \"$zonename\" does not exist."
         exit 1
      fi
   fi
}

######################################################################
# Subroutine for adding a zone
#
add_zone() {
   zonename="$1"

   #
   # Make sure that the zone type specified is valid
   #
   if [ "$zonetype" != 's' ]
   then
      if [ "$zonetype" != 'w' ];
      then 
         error_message "Must specify a valid zone type [w=whole root or s=sparse root]";
      fi
   fi

   #
   # Make sure that a valid interface was specified
   #
   if [ -z "$zoneif" ];
   then 
     defaultzoneif=`ifconfig -a | grep flags | cut -d: -f1 | uniq | grep -v lo0 | head -1`
     if [ -z "$defaultzoneif" ];
     then 
        error_message "No network interface available or specified";
     else 
        zoneif="$defaultzoneif"
     fi
   else
     ck4zoneif=`ifconfig -a | grep $zoneif`
     if [ -z "$ck4zoneif" ];then error_message "Network interface specified ($zoneif) does not exist";fi
   fi

   #
   # Make sure that an IP address was specified
   #
   if [ -z "$zoneip" ];then error_message "No zone ip";fi

   #
   # Make sure that a base zone path was specified
   #
   if [ -z "$zonepath" ];
   then 
      error_message "Must specify zone base directory with the -z <dir> flag";
   fi

   #
   # Ensure that the root password is specified
   #
   if [ -z "$encrootpw" ];
   then 
      error_message "Must specify either encrypted (-E) or non-encrypted (-P) password and the password cannot be null (e.g. \"\")";
   fi

   #
   # Ensure that zone name is specified
   #
   if [ -z "$zonename" ]
   then
      error_message "Must specify a zone name"
   else
      ################################################################
      # Create the zone config file
      #
      wholeroot=''
      if [ "$zonetype" = 'w' ]
      then
         wholeroot="
remove inherit-pkg-dir dir=/lib 
remove inherit-pkg-dir dir=/usr 
remove inherit-pkg-dir dir=/sbin 
remove inherit-pkg-dir dir=/platform"
      fi

      #
      # Construct readonly directories to insert into the zone config
      #
      i=0
      while [[ $i -lt $ronum ]]
      do
         globaldir=`echo ${rodirs[$i]} | cut -d"|" -f1`
         localdir=`echo ${rodirs[$i]} | cut -d"|" -f2`
         # If no dstdir specified, use the srcdir
         if [ -z "$dstdir"]
         then
            dstdir="$srcdir"
         fi
         rodirlist="$rodirlist
add fs
set dir=$localdir
set special=$globaldir
set type=lofs
add options [ro,nodevices]
end"
         i=$(($i+1))
      done

      #
      # Construct readwrite directories to insert into the zone config
      #
      i=0
      while [[ $i -lt $rwnum ]]
      do
         globaldir=`echo ${rwdirs[$i]} | cut -d"|" -f1`
         localdir=`echo ${rwdirs[$i]} | cut -d"|" -f2`
         # If no dstdir specified, use the srcdir
         if [ -z "$dstdir"]
         then
            dstdir="$srcdir"
         fi
         rwdirlist="$rwdirlist
add fs
set dir=$localdir
set special=$globaldir
set type=lofs
add options [rw,nodevices]
end"
         i=$(($i+1))
      done

      zonefile="/tmp/zone$$"
      cat >> $zonefile <<EOF
create
set zonepath=$zonepath/$zonename
set autoboot=true$wholeroot$rodirlist$rwdirlist
add net
set address=$zoneip
set physical=$zoneif
end
add attr
set name=comment
set type=string
set value="Zone $zonename"
end
verify
commit
EOF

      ################################################################
      # Make sure the zone path, rodirs[$ronum] and rwdirs[$rwnum] exists
      #
      mkdir -p "$zonepath" 2> /dev/null
      i=0
      while [[ $i -lt $ronum ]]
      do
         localdir=`echo ${rodirs[$i]} | cut -d"|" -f2`
         mkdir -p "$localdir" 2> /dev/null
         i=$(($i+1))
      done
      i=0
      while [[ $i -lt $rwnum ]]
      do
         localdir=`echo ${rwdirs[$i]} | cut -d"|" -f2`
         mkdir -p "$localdir" 2> /dev/null
         i=$(($i+1))
      done

      ################################################################
      # Add and configure the zone
      #
      ck4zone=`zoneadm -z "$zonename" list -v 2> /dev/null | grep "$zonename" | awk '{ print $3 }'`
      if [ -n "$ck4zone" ] 
      then
         echo "Error: Zone \"$zonename\" already exists and is in the $ck4zone state."
         exit 1
      fi
     
      zonecfg -z "$zonename" -f "$zonefile"
      zoneadm -z "$zonename" install
      if [ $? -ne 0 ] 
      then
         echo "Error: Zone installation failed."
         exit 1
      fi

      ################################################################
      # Generate a sysidcfg file
      #
      adddomain=''
      if [ -n "$domainname" ]
      then
        adddomain="domain_name=$domainname "
      fi

      nameservice='NONE'
      if [ -n "$domains" ]
      then
         nameservice="DNS {$adddomain name_server=$domains}"
      fi

      cat >> "$zonepath/$zonename/root/etc/sysidcfg" <<EOF
system_locale=C
terminal=xterm
network_interface=PRIMARY { hostname=$zonename ip_address=$zoneip protocol_ipv6=no }
security_policy=NONE
name_service=$nameservice
timezone=$TZ
root_password=$encrootpw
EOF

      ################################################################
      # Generate a NFS install state file so as to avoid being
      # prompted for NFS on boot.
      #
      touch "$zonepath/$zonename/root/etc/.NFS4inst_state.domain"

      ################################################################
      # Boot the zone for the first time
      #
      zoneadm -z "$zonename" boot

      ################################################################
      # Wait for manifest-import [dsscfg] to complete before attempting
      # to disable services.  
      #
      ck4startd='sysidcfg'
      while [ -n "$ck4startd" ]
      do
         sleep 3
         ck4startd=`ps -fz "$zonename" | egrep "sysid|svccfg|manifest|reboot|ssh-keygen|inetd-upgrade" | grep -v grep`
      done
   
      ################################################################
      # Wait for automatic post-install reboot to complete
      #
      #sleep 10
      ck4syslogd=`ps -fz "$zonename" | egrep "syslogd" | grep -v grep`
      # Wait for first boot to complete
      while [ -z "$ck4syslogd" ]
      do
         sleep 1
         ck4syslogd=`ps -fz "$zonename" | egrep "syslogd" | grep -v grep`
      done
   fi
}

######################################################################
# Subroutine for disabling or enabling all un-necessary OS services
#
run_manage_services() {
   if [ -z "$1" ];then error_message "Must specify zone name"; fi
   rzonepath=`zonecfg -z "$zonename" info zonepath 2> /dev/null | awk '{ print $2 }'`
   maction="$2"
   donothing=''
   case "$maction" in
      'disable') inetaction='-d';;
         'lock') maction='disable'; inetaction='-d';;
       'enable') inetaction='-e';;
       'unlock') maction='enable'; inetaction='-e';;
      *) donothing='true';;
   esac

   if [ "$donothing" = 'true' ]
   then
     error_message "Error: the -s flag must include a valid selection such as 'enable' or 'disable'"
   else
      #
      # Disable unnecessary legacy (rc) services
      #
      rc2="/etc/rc2.d"
      rc3="/etc/rc3.d"
      for i in $rc3/S16boot.server $rc3/S50apache $rc3/S52imq $rc3/S76snmpdx $rc3/S77dmi $rc3/S81volmgt $rc3/S82initsma $rc3/S84appserv $rc3/S90samba $rc2/S70uucp $rc2/S72autoinstall $rc2/S73cachefs.daemon $rc2/S89PRESERVE $rc2/S90wbem $rc2/S90webconsole $rc2/S98deallocate $rc2/S99audit $rc2/S99dtlogin
      do
         j=`echo $i | sed -e "s/d\/S/d\/s/g"`
         if [ "$maction" = 'disable' ]
         then
            if [ -e "$rzonepath/root/$i" ]
            then
               zlogin "$zonename" "mv $i $j;$j stop > /dev/null 2>&1"
            fi
         elif [ "$maction" = 'enable' ]
         then
            if [ -e "$rzonepath/root/$j" ]
            then
               zlogin "$zonename" "mv $j $i;$i start > /dev/null 2>&1"
            fi
         fi
      done

      #
      # Disable unnecessary sfw services
      #
      zlogin $zonename "svcadm $maction svc:/network/smtp:sendmail" 
      zlogin $zonename "svcadm $maction svc:/system/filesystem/autofs:default" 
      zlogin $zonename "svcadm $maction svc:/network/nfs/status:default" 
      zlogin $zonename "svcadm $maction svc:/network/nfs/nlockmgr:default" 
      zlogin $zonename "svcadm $maction svc:/network/nfs/client:default" 
      zlogin $zonename "svcadm $maction svc:/network/nfs/rquota:default" 
      zlogin $zonename "svcadm $maction svc:/network/rpc/bind:default"
   
      #
      # Disable unnecessary inet services
      #
      zlogin $zonename "inetadm $inetaction svc:/application/font/stfsloader:default"
      zlogin $zonename "inetadm $inetaction svc:/application/x11/xfs:default"
      zlogin $zonename "inetadm $inetaction svc:/network/finger:default"
      zlogin $zonename "inetadm $inetaction svc:/network/ftp:default"
      zlogin $zonename "inetadm $inetaction svc:/network/login:rlogin"
      zlogin $zonename "inetadm $inetaction svc:/network/rpc/gss:default"
      zlogin $zonename "inetadm $inetaction svc:/network/rpc/rstat:default"
      zlogin $zonename "inetadm $inetaction svc:/network/rpc/rusers:default"
      zlogin $zonename "inetadm $inetaction svc:/network/rpc/smserver:default"
      zlogin $zonename "inetadm $inetaction svc:/network/security/ktkt_warn:default"
      zlogin $zonename "inetadm $inetaction svc:/network/shell:default"
      zlogin $zonename "inetadm $inetaction svc:/network/telnet:default"
      zlogin $zonename "inetadm $inetaction svc:/network/rpc-100235_1/rpc_ticotsord:default"
      zlogin $zonename "inetadm $inetaction svc:/network/rpc-100083_1/rpc_tcp:default"
      zlogin $zonename "inetadm $inetaction svc:/network/rpc-100068_2-5/rpc_udp:default"
      zlogin $zonename "inetadm $inetaction svc:/application/print/rfc1179"
   fi
}

######################################################################
# If any parameters were passed evaluate their usage...
while getopts a:n:z:P:E:I:i:t:r:w:R:d:D:C:s:S:hv OPT
do
   case $OPT in
   a|+a) if [ -z "$OPTARG" ];then error_message "Must provide a valid action with the -a flag";fi
         action="$OPTARG"
         ;;
   n|+n) if [ -z "$OPTARG" ];then error_message "Must provide a zone name with the -n flag";fi
         zonename="$OPTARG"
         ;;
   z|+z) if [ -z "$OPTARG" ];then error_message "Must provide a base zone directory with the -z flag";fi
         zonepath="$OPTARG"
         ;;
   P|+P) if [ -z "$OPTARG" ];then error_message "Must provide an unencrypted password with the -P flag and the password cannot be null (e.g. \"\")";fi
         rootpw="$OPTARG"
         # Encrypt the password
         encrootpw=`/usr/bin/perl -e "print crypt(\"$rootpw\", (('a'..'z', 'A'..'Z', '0'..'9', '.', '/')[int(rand(64))].('a'..'z', 'A'..'Z', '0'..'9', '.', '/')[int(rand(64))]));"`
         ;;
   E|+E) if [ -z "$OPTARG" ];then error_message "Must provide an encrypted password with the -E flag";fi
         encrootpw="$OPTARG"
         ;;
   I|+I) if [ -z "$OPTARG" ];then error_message "Must provide a valid IP address with the -I flag";fi
         zoneip="$OPTARG"
         ;;
   i|+i) if [ -z "$OPTARG" ];then error_message "";fi
         zoneif="$OPTARG"
         ;;
   t|+t) if [ -z "$OPTARG" ];then error_message "Must specify a valid zone type (w or s) with the -t flag";fi
         zonetype="$OPTARG"
         ;;
   r|+r) if [ -z "$OPTARG" ];then error_message "";fi
         rodirs[$ronum]="$OPTARG"
         globaldir=`echo ${rodirs[$ronum]} | cut -d"|" -f1`
         if [ -d "$globaldir" ]; then true;
         elif [ -e "$globaldir" ]; then true;
         else error_message "The global directory \"$globaldir\" does not exist."; fi
         ronum=$(($ronum+1))
         ;;
   w|+w) if [ -z "$OPTARG" ];then error_message "";fi
         rwdirs[$rwnum]="$OPTARG"
         rwnum=$(($rwnum+1))
         ;;
   R|+R) if [ -z "$OPTARG" ];then error_message "";fi
         roothomedir="$OPTARG"
         ;;
   d|+d) if [ -z "$OPTARG" ];then error_message "";fi
         if [ -n "$domains" ]
         then 
            domains="$domains,$OPTARG"
         else 
            domains="$OPTARG"
         fi
         ;;
   D|+D) if [ -z "$OPTARG" ];then error_message "";fi
         domainname="$OPTARG"
         ;;
   C|+C) if [ -z "$OPTARG" ];then error_message "";fi
         files[$fnum]="$OPTARG"
         fnum=$(($fnum+1))
         ;;
   s|+s) if [ -z "$OPTARG" ];then error_message "Must provide enable or disable option for the -s <option> flag";fi
         manage_services="$OPTARG"
         ;;
   S|+S) if [ -z "$OPTARG" ];then error_message "Must provide a service name with the -s <service> flag";fi
         services[$snum]="$OPTARG"
         snum=$(($snum+1))
         ;;
   h|+h) usage;;
   v|+v) echo "zonemgr version $version"; exit 0;;
      *) usage;;
   esac
done
shift `expr $OPTIND - 1`

if [ -z "$zonename" ]
then 
   if [ "$action" != 'list' ]
   then 
      error_message "Must provide the zone name"
   fi
fi

#
# Verify for supported operating system version
#
osver=`uname -sr`
if [ "$osver" != 'SunOS 5.10' ]
then
   error_message "This script will only work on Solaris 10."
fi

#
# Verify that the zones packages are installed
#
ck4zones=`pkginfo SUNWzoner SUNWzoneu | egrep -c "zoner|zoneu"`
if [ "$ck4zones" -ne 2 ]
then
   error_message "The zones packages (SUNWzoner and SUNWzoneu) must be installed."
fi

#
# Verify dependencies exist
#
ck4perl=`which perl 2> /dev/null| grep -v "^no perl"`
if [ -z "$ck4perl" ]
then
   error_message "Perl must be installed."
fi

case "$action" in
   'add') add_zone "$zonename"
          if [ -n "$manage_services" ]
          then
             run_manage_services "$zonename" "$manage_services"
          fi
          ;;
   'del') delete_zone "$zonename"
          manage_services=''
          fnum=0
          roothomedir=''
          ;;
   'list') zoneadm list -cv; files=''; roothomedir='';;
   'lock') run_manage_services "$zonename" 'disable';;
   'unlock') run_manage_services "$zonename" 'enable';;
   'shutdown') zlogin "$zonename" "shutdown -y -g 0 -i 5"; files=''; roothomedir='';;
   'halt') zoneadm -z "$zonename" halt; files=''; roothomedir='';;
   'boot') zoneadm -z "$zonename" boot; files=''; roothomedir='';;
   'reboot') zoneadm -z "$zonename" reboot; files=''; roothomedir='';;
   *) error_message "Error: \"$action\" is not a valid action";;
esac

######################################################################
# Set the home directory of the root user to /root
#
if [ -n "$roothomedir" ]
then
   mkdir -p "$zonepath/$zonename/root/$roothomedir"
   chroot "$zonepath/$zonename/root" /usr/sbin/usermod -d "$roothomedir" root
fi

######################################################################
# Copy specified files from global into the global zone
#
i=0
while [[ $i -lt $fnum ]]
do
   if [ -e "${files[$i]}" ]
   then
      cp "${files[$i]}" "$zonepath/$zonename/root/${files[$i]}"
   else
      echo "File \"${files[$i]}\" does not exist."
   fi
   i=$(($i+1))
done

######################################################################
# Clean up
#
if [ -e "$zonefile" ]; then rm "$zonefile"; fi

######################################################################
# Restart requested services (so that any changes made to will take 
# effect)
#
if [ "$action" = 'add' ]
then
   i=0
   while [[ $i -lt $snum ]]
   do
      if [ "${services[$i]}" = 'reboot' ]
      then
         zoneadm -z "$zonename" reboot
      else
         #
         # Determine if the service is 
         #
         ck4svc=`zlogin "$zonename" "svcs -H \"${services[$i]}\"" | awk '{ print $1 }'`
         if [ "$ck4svc" = 'online' ]
         then
            zlogin "$zonename" "svcadm restart ${services[$i]}"
         else
            echo "Error: Service \"${services[$i]}\" does not exist."
         fi
      fi
      i=$(($i+1))
   done
fi


##############################################################################
### This script is submitted to BigAdmin by a user of the BigAdmin community.
### Sun Microsystems, Inc. is not responsible for the
### contents or the code enclosed. 
###
###
### Copyright 2005 Sun Microsystems, Inc. ALL RIGHTS RESERVED
### Use of this software is authorized pursuant to the
### terms of the license found at
### http://www.sun.com/bigadmin/common/berkeley_license.html
##############################################################################


