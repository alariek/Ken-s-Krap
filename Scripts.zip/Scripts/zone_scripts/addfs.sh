add fs
set dir=/dbspace
set special=/dev/dsk/c2t50001FE150010BCCd12s0
set raw=/dev/rdsk/c2t50001FE150010BCCd12s0
set type=ufs
end



###############################################
###
###/dev/dsk/c2t50001FE150010BCCd1s0	/dev/rdsk/c2t50001FE150010BCCd1s0	/dbspace	ufs	2	yes	-
###/dev/dsk/c2t50001FE150010BCCd2s0	/dev/rdsk/c2t50001FE150010BCCd2s0	/dbspace	ufs	2	yes	-
###/dev/dsk/c2t50001FE150010BCCd3s0	/dev/rdsk/c2t50001FE150010BCCd3s0	/dbspace	ufs	2	yes	-
###/dev/dsk/c2t50001FE150010BCCd4s0	/dev/rdsk/c2t50001FE150010BCCd4s0	/dbspace	ufs	2	yes	-
###/dev/dsk/c2t50001FE150010BCCd5s0	/dev/rdsk/c2t50001FE150010BCCd5s0	/dbspace	ufs	2	yes	-
###/dev/dsk/c2t50001FE150010BCCd6s0	/dev/rdsk/c2t50001FE150010BCCd6s0	/dbspace	ufs	2	yes	-
###/dev/dsk/c2t50001FE150010BCCd7s0	/dev/rdsk/c2t50001FE150010BCCd7s0	/dbspace	ufs	2	yes	-
###/dev/dsk/c2t50001FE150010BCCd8s0	/dev/rdsk/c2t50001FE150010BCCd8s0	/dbspace	ufs	2	yes	-
###/dev/dsk/c2t50001FE150010BCCd9s0	/dev/rdsk/c2t50001FE150010BCCd9s0	/dbspace	ufs	2	yes	-
###/dev/dsk/c2t50001FE150010BCCd10s0	/dev/rdsk/c2t50001FE150010BCCd10s0	/dbspace	ufs	2	yes	-
###/dev/dsk/c2t50001FE150010BCCd11s0	/dev/rdsk/c2t50001FE150010BCCd11s0	/dbspace	ufs	2	yes	-
###/dev/dsk/c2t50001FE150010BCCd12s0	/dev/rdsk/c2t50001FE150010BCCd12s0	/dbspace	ufs	2	yes	-

