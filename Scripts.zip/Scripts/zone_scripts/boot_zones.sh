zoneadm -z oma3s036c1 boot &
zoneadm -z oma3s036c2 boot &
zoneadm -z oma3s036c3 boot &
zoneadm -z oma3s036c4 boot &
zoneadm -z oma3s036c5 boot &
zoneadm -z oma3s036c6 boot &
zoneadm -z oma3s036c7 boot &
