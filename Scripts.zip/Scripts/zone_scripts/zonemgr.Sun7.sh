Usage: ./zonemgr.sh -a <action> -n <name>
     -a <action>   = Management action
                       add - Add a zone
                       del - Delete a zone
                       list - List current zones
                       lock - Disable all un-necessary services
                       unlock - Modify the configuration of a zone
                       shutdown - Shutdown a zone
                       halt - Halt a zone
                       boot - Boot a zone
                       reboot - Reboot a zone
       -n "<name>" = Zone name

   Action specific usage:
     add - Add a zone
       -z "<dir>"          = Base directory for this zone
       -P "<password>"     = Unencrypted non-global zone root password
       -E "<enc_password>" = Encrypted non-global zone root password (cut/paste from /etc/shadow)
       -I "<IP Address>"   = IP Address of the non-global zone
       -i "<interface>"    = Network interface of the non-global zone
                               [default: first non-loopback interface listed by ifconfig]
       -t [w|s]              = Type of zone where w=Whole Root and s=Sparse [default: s]
       -r "<gdir>|<ldir>"  = Mount global zone directory (gdir) on a non-global zone directory (ldir) in readonly mode
       -w "<gdir>|<ldir>"  = Mount global zone directory (gdir) on a non-global zone directory (ldir) in read write mode
       -R "<dir>"          = Custom home directory for root user
       -d "<ns1>,<ns2>,.." = DNS Name Servers
       -D "<domain>"       = DNS Domain Name
       -C "<file>"         = File to copy from the global zone
       -s enable or disable  = Enable (unlock) or disable (lock down) operating system services
       -S "service"        = Service to restart after adding zone.  Special case is 'reboot' to restart all services in the zone.
       -h                    = See this usage information
       -v                    = See the version number of this script

./zonemgr.sh -a add  -z /zone_root -P zone1pw -I 172.17.3.121 -t s -R /root  -n oma3s007c1 -d 172.16.1.25,172.17.1.106 -D am.tsacorp.com -C /root/.profile
./zonemgr.sh -a add  -z /zone_root -P zone2pw -I 172.17.3.122 -t s -R /root  -n oma3s007c2 -d 172.16.1.25,172.17.1.106 -D am.tsacorp.com -C /root/.profile
./zonemgr.sh -a add  -z /zone_root -P zone3pw -I 172.17.3.123 -t s -R /root  -n oma3s007c3 -d 172.16.1.25,172.17.1.106 -D am.tsacorp.com -C /root/.profile
./zonemgr.sh -a add  -z /zone_root -P zone4pw -I 172.17.3.124 -t s -R /root  -n oma3s007c4 -d 172.16.1.25,172.17.1.106 -D am.tsacorp.com -C /root/.profile
./zonemgr.sh -a add  -z /zone_root -P zone4pw -I 172.17.3.125 -t w -R /root  -n oma3s007c5 -d 172.16.1.25,172.17.1.106 -D am.tsacorp.com -C /root/.profile
