#!/bin/bash

###################################
#
# Hadoop cleanup script - hadoop-cleanup.sh

#
# Created  6th September 2017  - Dean Rossi

#
# Purpose - to help clear disk usage errors when avamar fills /ar/ gets filled
 
#           by hadoop logs etc.

#
# This would run is a Crontab script

# Some thing like the Following so it runs once every day at 5:00am.
 
# Assuming crontab is enabled on the machine

#
###0 5 * * * /usr/bin/haddop-cleanup.sh

#
####################################


#Set Log file details
# Set Date Variable  so it only logs a Days date 

NOW=$(date +"%Y%m%d")


# Set Log File
LOGFILE="/var/log/hadoop_cleanup-$NOW.log"
# Set length of time to keep logs etc. currnetly set to 15
KEEPDATE=15


# Log files to be deleted.

find /var/log/hive/hive*.log.* -mtime $KEEPDATE >> $LOGFILE
find /var/log/hbase/phoenix-hbase-server.log.* -mtime $KEEPDATE
 >> $LOGFILE
find /var/log/hbase/gc.log* -mtime $KEEPDATE                    >> $LOGFILE
find /var/log/hadoop/hdfs/hdfs-audit.log* -mtime $KEEPDATE      >> $LOGFILE


# Delete files.


find /var/log/hive/hive*.log.* -mtime $KEEPDATE -exec rm {} \;
find /var/log/hbase/phoenix-hbase-server.log.* -mtime $KEEPDATE -exec rm {} \;
find /var/log/hbase/gc.log* -mtime $KEEPDATE -exec rm {} \;
find /var/log/hadoop/hdfs/hdfs-audit.log* -mtime $KEEPDATE -exec rm {} \;


# Clean up old Hadoop clean up logs files
find /var/log/hadoop_cleanup* -mtime +7  >> $LOGFILE
find /var/log/hadoop_cleanup* -mtime +7 -exec rm {} \; 





Ping Test
 Interpartition Logical LAN: U8408.E8D.06C029T-V8-C2-T1
 Speed, Duplex: auto,auto
 Client IP Address: 10.5.75.212
 Server IP Address: 10.5.75.36
 Gateway IP Address: 10.5.75.254
 Subnet Mask: 255.255.255.0
 Protocol: Standard
 Spanning Tree Enabled: 0
 Connector Type: 
 VLAN Priority: 0
 VLAN ID: 0
 VLAN Tag: 